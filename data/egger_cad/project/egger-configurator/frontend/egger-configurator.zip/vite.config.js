import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [
    react(),
    {
      name: 'custom-middleware',
      configureServer(server) {
        // Health‑check endpoint
        server.middlewares.use('/api/health', (req, res) => {
          res.statusCode = 200;
          res.end('OK');
        });
        // Simple Prometheus metrics endpoint
        server.middlewares.use('/metrics', (req, res) => {
          const metrics = `# HELP app_requests_total Total number of requests\n# TYPE app_requests_total counter\napp_requests_total 42\n`;
          res.setHeader('Content-Type', 'text/plain; version=0.0.4');
          res.end(metrics);
        });
      },
    },
  ],
  build: {
    chunkSizeWarningLimit: 500,
    rollupOptions: {
      external: ['three'],
      output: {
        globals: {
          three: 'THREE',
        },
        manualChunks(id) {
          if (id.includes('node_modules')) {
            const parts = id.split('node_modules/')[1].split('/');
            return parts[0];
          }
        },
      },
    },
  },
});