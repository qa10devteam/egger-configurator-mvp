describe('Egger Configurator flow', () => {
  it('should complete wizard and show 3D preview', () => {
    cy.visit('/')
    // step 1: select first product
    cy.get('ul[aria-label="product list"] li').first().click()
    // step 2: select first material
    cy.get('ul[aria-label="material list"] li').first().click()
    // step 3: enter dimensions
    cy.get('input[name="width"]').type('500')
    cy.get('input[name="height"]').type('300')
    cy.get('input[name="depth"]').type('200')
    cy.contains('Dalej →').click()
    // step 4: verify canvas exists
    cy.get('canvas').should('exist')
  })
});
