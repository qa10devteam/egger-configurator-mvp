import React from 'react';

// Simple responsive wrapper – uses CSS flexbox with wrap.
export const ResponsiveLayout = ({ children }) => (
  <div style={{
    display: 'flex',
    flexWrap: 'wrap',
    gap: '1rem',
    justifyContent: 'center',
  }}>
    {children}
  </div>
);
