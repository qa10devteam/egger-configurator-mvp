import React, { useEffect } from 'react';

// Placeholder for analytics integration (e.g., Google Analytics, Plausible)
export const Analytics = () => {
  useEffect(() => {
    // Example: window.gtag('config', 'GA_MEASUREMENT_ID');
    console.log('Analytics initialized (placeholder)');
  }, []);
  return null;
};
