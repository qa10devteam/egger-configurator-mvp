import React from 'react';
import Wizard from './Wizard';
import { FeatureFlagsProvider } from './FeatureFlags';
import ErrorBoundary from './ErrorBoundary';
import { SEO } from './SEO';
import { Analytics } from './Analytics';
import { SentryInit } from './Sentry';
import { DarkModeToggle } from './DarkModeToggle';
import { ResponsiveLayout } from './ResponsiveLayout';
import styled from 'styled-components';
import { ThemeProvider } from './theme/ThemeContext';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient();

const Container = styled.div`
  font-family: ${props => props.theme.fontFamily};
  padding: ${props => props.theme.spacing.md};
  background: ${props => props.theme.colors};
`;

function App() {
  return (
    <FeatureFlagsProvider>
      <ThemeProvider>
        <QueryClientProvider client={queryClient}>
          <ErrorBoundary>
            <SEO title="Egger + Homag Configurator" description="Interactive configurator for Egger + Homag products" />
            <Analytics />
            <SentryInit />
            <DarkModeToggle />
            <Container>
              <h1>Egger + Homag Configurator</h1>
              <ResponsiveLayout>
                <Wizard />
              </ResponsiveLayout>
            </Container>
          </ErrorBoundary>
        </QueryClientProvider>
      </ThemeProvider>
    </FeatureFlagsProvider>
  );
}

export default App;
