import React, { useEffect } from 'react';
import { useFeatureFlags } from './FeatureFlags';

export const DarkModeToggle = () => {
  const flags = useFeatureFlags();
  const enabled = flags.darkMode;

  useEffect(() => {
    if (enabled) {
      document.body.style.backgroundColor = '#121212';
      document.body.style.color = '#ffffff';
    } else {
      document.body.style.backgroundColor = '';
      document.body.style.color = '';
    }
  }, [enabled]);

  return null; // No UI – just applies the theme based on flag.
};
