import React from 'react';

export const Skeleton = ({ width = '100%', height = '1rem', style = {} }) => (
  <div
    style={{
      backgroundColor: '#e0e0e0',
      width,
      height,
      borderRadius: '4px',
      ...style,
    }}
  />
);
