import React, { useEffect } from 'react';
import * as Sentry from '@sentry/react';
import { BrowserTracing } from '@sentry/tracing';

export const SentryInit = () => {
  useEffect(() => {
    Sentry.init({
      dsn: process.env.VITE_SENTRY_DSN || '',
      integrations: [new BrowserTracing()],
      tracesSampleRate: 1.0,
    });
    console.log('Sentry initialized');
  }, []);
  return null;
};
