import { set, get } from 'idb-keyval';

export const cacheProducts = async (products) => {
  try {
    await set('products', products);
  } catch (e) {
    console.error('Failed to cache products', e);
  }
};

export const getCachedProducts = async () => {
  try {
    const data = await get('products');
    return data || [];
  } catch (e) {
    console.error('Failed to read cached products', e);
    return [];
  }
};
