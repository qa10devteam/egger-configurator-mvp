import React, { useEffect, useState, Suspense } from 'react';
import axios from 'axios';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Box, useGLTF } from '@react-three/drei';

// Placeholder product type
// { id: string, name: string, modelUrl?: string }

function Model({ url }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} scale={1} />;
}
// { id: string, name: string, modelUrl?: string }

function Configurator() {
  const [products, setProducts] = useState([]);
  const [selected, setSelected] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    // In a real app replace with actual endpoint
    axios.get('/products.json')
      .then(res => setProducts(res.data))
      .catch(err => setError(err.message));
  }, []);

  const handleSelect = (product) => {
    setSelected(product);
  };

  return (
    <div style={{ display: 'flex', gap: '2rem' }}>
      <div style={{ flex: '1 1 0' }}>
        <h2>Produkty</h2>
        {error && <p style={{ color: 'red' }}>Błąd ładowania: {error}</p>}
        <ul>
          {products.map(p => (
            <li key={p.id} style={{ cursor: 'pointer', marginBottom: '0.5rem' }} onClick={() => handleSelect(p)}>
              {p.name}
            </li>
          ))}
        </ul>
      </div>
      <div style={{ flex: '2 1 0', height: '400px', border: '1px solid #ccc' }}>
        <h2>Podgląd 3D</h2>
        <Suspense fallback={null}><Canvas camera={{ position: [2, 2, 2] }}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[5, 5, 5]} intensity={0.8} />
          <OrbitControls />
          {selected && selected.modelUrl ? (
            <Model url={selected.modelUrl} />
          ) : (
            <Box args={[1, 1, 1]}>
              <meshStandardMaterial color={selected ? '#4caf50' : '#2196f3'} />
            </Box>
          )}
        </Canvas></Suspense>
      </div>
    </div>
  );
}

export default Configurator;
