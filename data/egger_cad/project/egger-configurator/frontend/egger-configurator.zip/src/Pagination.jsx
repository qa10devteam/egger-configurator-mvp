import React from 'react';

export const Pagination = ({ totalItems, itemsPerPage = 10, currentPage, onPageChange }) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  if (totalPages <= 1) return null;
  const pages = [];
  for (let i = 1; i <= totalPages; i++) {
    pages.push(i);
  }
  return (
    <div style={{ marginTop: '1rem' }}>
      {pages.map(p => (
        <button
          key={p}
          onClick={() => onPageChange(p)}
          style={{
            marginRight: '0.5rem',
            fontWeight: p === currentPage ? 'bold' : 'normal',
          }}
        >
          {p}
        </button>
      ))}
    </div>
  );
};
