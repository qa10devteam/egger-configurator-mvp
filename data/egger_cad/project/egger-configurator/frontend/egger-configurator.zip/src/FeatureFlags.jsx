import React, { createContext, useContext, useState } from 'react';

// Simple feature flag context – can be extended to fetch flags from a remote config.
const FeatureFlagsContext = createContext({});

export const FeatureFlagsProvider = ({ children }) => {
  // Example flags – in a real app these could be loaded from an API or env vars.
  const [flags] = useState({
    darkMode: true,
    new3DViewer: false,
    betaMaterialSelection: true,
  });

  return (
    <FeatureFlagsContext.Provider value={flags}>
      {children}
    </FeatureFlagsContext.Provider>
  );
};

export const useFeatureFlags = () => useContext(FeatureFlagsContext);
