# Pozostałe fazy (31‑50) – plan kontynuacji Egger + Homag Configurator

> **Cel:** Dokończenie pełnego cyklu rozwoju, od optymalizacji wydajności po wdrożenie monitoringu i retrospektywę po wydaniu.

---

## Faza 31 – Budżet wydajności
- **Opis:** Wymusić limit rozmiaru chunków < 500 KB.
- **Kroki:**
  1. Otworzyć `vite.config.js`.
  2. Dodać w sekcji `build` opcję `chunkSizeWarningLimit: 500`.
  3. Uruchomić `npm run build` i zweryfikować brak ostrzeżeń przekraczających limit.

## Faza 32 – Code‑splitting dla podglądu 3D
- **Opis:** Lazy‑load komponentu 3‑D, aby nie obciążał początkowego bundle.
- **Kroki:**
  1. Przenieść kod `<Canvas …>` do nowego pliku `src/ThreeViewer.jsx`.
  2. W `Wizard.jsx` zamienić import na `const ThreeViewer = React.lazy(() => import('./ThreeViewer'))`.
  3. Owinąć użycie komponentu w `<React.Suspense fallback={<Skeleton height="300px" />}>…</React.Suspense>`.

## Faza 33 – Lazy‑load modeli GLTF
- **Opis:** Pobierać model 3‑D dopiero po wyborze produktu.
- **Kroki:**
  1. `ThreeViewer.jsx` przyjmuje prop `modelUrl`.
  2. Użyć `useLoader(GLTFLoader, modelUrl)` (dynamiczny import).
  3. W `Wizard.jsx` po wybraniu produktu przekazać `selectedProduct.modelUrl` do `ThreeViewer`.

## Faza 34 – Powiadomienia Slack w CI
- **Opis:** Wysyłać alert do Slacka przy niepowodzeniu CI.
- **Kroki:**
  1. Dodać sekretny zmienny `SLACK_WEBHOOK_URL` w repozytorium.
  2. Rozszerzyć `.github/workflows/ci.yml` o krok po `Upload artifact`:
```yaml
- name: Slack alert on failure
  if: failure()
  run: |
    curl -X POST -H 'Content-type: application/json' \
      --data "{\"text\": \"CI failed for ${{ github.sha }}\"}" ${{ secrets.SLACK_WEBHOOK_URL }}
```

## Faza 35 – Skrypt podbijania wersji
- **Opis:** Automatyzować bump wersji i generowanie changeloga.
- **Kroki:**
  1. W `package.json` dodać skrypt: `"release": "standard-version"`.
  2. Po każdej udanej releasie uruchomić `npm run release` – zwiększy wersję, wygeneruje `CHANGELOG.md` i zataguje commit.

## Faza 36 – Generowanie changeloga
- **Opis:** `standard-version` automatycznie tworzy changelog na podstawie commitów.
- **Kroki:**
  1. Upewnić się, że w `package.json` jest pole `standard-version` (domyślne).
  2. Po `npm run release` sprawdzić aktualizację `CHANGELOG.md`.

## Faza 37 – Workflow wydania (GitHub Actions)
- **Opis:** Tag, budowa obrazu Docker i publikacja do GHCR.
- **Kroki:**
  1. Dodać plik `.github/workflows/release.yml` z triggerem `on: push` na tagi `v*`.
  2. Krok *Build Docker image*: `docker build -t ghcr.io/<owner>/egger-configurator:$GITHUB_REF_NAME .`.
  3. Krok *Push*: `docker push ghcr.io/<owner>/egger-configurator:$GITHUB_REF_NAME`.

## Faza 38 – Endpoint health‑check
- **Opis:** Prosty endpoint zwracający `200 OK` dla monitoringu.
- **Kroki:**
  1. Dodać middleware w `vite.config.js`:
```js
export default defineConfig({
  plugins: [
    // …
    {
      name: 'health-check',
      configureServer(server) {
        server.middlewares.use('/api/health', (req, res) => {
          res.statusCode = 200;
          res.end('OK');
        });
      },
    },
  ],
});
```
  2. Zweryfikować pod adresem `http://localhost:5173/api/health`.

## Faza 39 – Dashboard monitoringu (Grafana + Prometheus)
- **Opis:** Szkielet monitoringu aplikacji.
- **Kroki:**
  1. Rozszerzyć `docker-compose.yml` o serwisy `prometheus` i `grafana`.
  2. Dodać prosty exporter w aplikacji (`/metrics` zwracający `process_cpu_seconds_total`).
  3. Skonfigurować `prometheus.yml` do scrapowania `frontend:5173/metrics`.
  4. W Grafanie dodać dashboard z wykresami CPU, pamięci i liczby żądań.

## Faza 40 – Retrospektywa po wydaniu
- **Opis:** Dokumentacja wniosków i planowanie kolejnego sprintu.
- **Kroki:**
  1. Stworzyć plik `docs/post-release-review.md` z sekcjami:
     - *Co poszło dobrze*
     - *Co wymaga poprawy*
     - *Nowe backlog items*.
  2. Po każdym wydaniu otworzyć issue, dołączyć link do changeloga i do `post-release-review.md`.
  3. Przenieść otwarte zadania do backlogu kolejnego sprintu.

---

### Jak używać tego dokumentu
1. **Skopiuj** zawartość `docs/remaining-phases.md` do nowego wątku w Discordzie.
2. **Zadeklaruj**, którą fazę chcesz rozpocząć – będę automatycznie wykonywać wszystkie niezbędne kroki.
3. **Po zakończeniu** każdej fazy, zaktualizuj ten plik (np. zaznaczając ✅ przy ukończonych pozycjach).

> **Gotowy do dalszej pracy!** Jeśli potrzebujesz, mogę od razu wykonać pierwszą z powyższych faz.

---

## Faza 41 – Audyt bezpieczeństwa
- **Opis:** Przeprowadzić przegląd bezpieczeństwa aplikacji i infrastruktury.
- **Kroki:**
  1. Dodać zależność `npm audit` i uruchomić `npm audit` w CI.
  2. Skonfigurować `snyk` w GitHub Actions, aby blokował merge przy wysokich zagrożeniach.
  3. Przeprowadzić skanowanie kontenerów Docker (`trivy`) w workflow wydania.

## Faza 42 – Testy end‑to‑end (Cypress)
- **Opis:** Zautomatyzować testy UI w przeglądarce.
- **Kroki:**
  1. Zainstalować Cypress: `npm i -D cypress`.
  2. Dodać przykładowe testy w `cypress/integration/flow.spec.js` obejmujące wybór produktu i podgląd 3‑D.
  3. Dodać krok do CI: `npm run cypress:run` po buildzie.

## Faza 43 – Testy wydajności (Lighthouse CI)
- **Opis:** Monitorować wydajność frontendu.
- **Kroki:**
  1. Zainstalować `@lhci/cli`: `npm i -D @lhci/cli`.
  2. Dodać skrypt `"lhci": "lhci autorun"` w `package.json`.
  3. Uruchomić w CI po deployu i zapisywać raporty jako artefakty.

## Faza 44 – Internationalisation (i18n)
- **Opis:** Przygotować aplikację do obsługi wielu języków.
- **Kroki:**
  1. Zainstalować `react-i18next` i `i18next`.
  2. Utworzyć katalog `src/locales/pl` i `src/locales/en` z plikami tłumaczeń.
  3. Owinąć UI w `<I18nextProvider>` i dodać przełącznik języka.

## Faza 45 – Dokumentacja API (Swagger)
- **Opis:** Udokumentować backendowe endpointy używane przez frontend.
- **Kroki:**
  1. Dodać `swagger-ui-express` i `swagger-jsdoc` do backendu.
  2. Utworzyć plik `swagger.yaml` opisujący `/api/health`, `/api/metrics` i inne.
  3. Udostępnić UI pod `/api/docs` i dodać link w README.

## Faza 46 – CI/CD – Deploy na Vercel
- **Opis:** Skonfigurować automatyczny deploy na Vercel po tagu.
- **Kroki:**
  1. Dodać Vercel CLI do repozytorium (`npm i -g vercel`).
  2. Utworzyć plik `vercel.json` z ustawieniami build.
  3. W GitHub Actions dodać krok `vercel --prod --token ${{ secrets.VERCEL_TOKEN }}` po udanym buildzie.

## Faza 47 – Testy użyteczności (User Testing)
- **Opis:** Przeprowadzić sesje testowe z rzeczywistymi użytkownikami.
- **Kroki:**
  1. Przygotować scenariusze testowe (wybór produktu, konfiguracja, zapis).
  2. Skorzystać z narzędzia `lookback` lub `usertesting.com` i zebrać feedback.
  3. Zgłosić znalezione problemy jako issue w repozytorium.

## Faza 48 – Skalowanie backendu (Kubernetes)
- **Opis:** Przenieść backend do klastra K8s dla lepszej skalowalności.
- **Kroki:**
  1. Utworzyć `Dockerfile` dla backendu (jeśli jeszcze nie istnieje).
  2. Napisać manifesty `deployment.yaml`, `service.yaml` i `ingress.yaml`.
  3. Zastosować w klastrze testowym i zweryfikować autoscaling HPA.

## Faza 49 – Backup i Disaster Recovery
- **Opis:** Zapewnić regularne backupy danych i plan przywracania.
- **Kroki:**
  1. Skonfigurować `pg_dump` (lub inny DB) w cronjobie codziennym.
  2. Przechowywać backupy w zaszyfrowanym bucket S3.
  3. Przetestować odtworzenie z backupu na środowisku staging.

## Faza 50 – Retrospektywa końcowa i roadmapa
- **Opis:** Podsumowanie projektu, wnioski i plan dalszych prac.
- **Kroki:**
  1. Zaktualizować `docs/post-release-review.md` o sekcję *Podsumowanie projektu*.
  2. Przeprowadzić spotkanie zespołu, zebrać wnioski i zapisać w `docs/roadmap-next.md`.
  3. Zarchiwizować repozytorium (tag `v1.0.0-final`) i przygotować szablon nowego projektu.

---

## Faza 51 – Refaktoryzacja komponentów UI
- **Opis:** Uporządkować i podzielić duże komponenty React na mniejsze, łatwiejsze w utrzymaniu.
- **Kroki:**
  1. Przejrzeć komponenty w `src/components` pod kątem wielkości (>300 linii).
  2. Wyodrębnić logikę do własnych hooków (`useXyz`).
  3. Stworzyć testy jednostkowe dla nowych małych komponentów.

## Faza 52 – System design tokens
- **Opis:** Centralny system kolorów, typografii i odstępów.
- **Kroki:**
  1. Zainstalować `@radix-ui/colors` i `styled-components` (lub `tailwindcss` config).
  2. Zdefiniować plik `src/theme/designTokens.ts` z tokenami.
  3. Przełączyć wszystkie style na tokeny, usuwając hard‑coded wartości.

## Faza 53 – Responsywne siatki (CSS Grid & Flexbox)
- **Opis:** Zapewnić płynne układy na wszystkie rozdzielczości.
- **Kroki:**
  1. Przeanalizować istniejące layouty, zamienić `float`/`inline‑block` na Grid/Flex.
  2. Dodać breakpointy w `tailwind.config.js` (sm, md, lg, xl).
  3. Testować w przeglądarkach devtools na szerokościach 320‑1920 px.

## Faza 54 – Animacje i mikro‑interakcje
- **Opis:** Dodanie płynnych przejść i feedbacku UI.
- **Kroki:**
  1. Zainstalować `framer-motion`.
  2. Dodać animacje wejścia/wyjścia do modalów i kart.
  3. Stworzyć komponent `Button` z efektem `whileHover` i `whileTap`.

## Faza 55 – Optymalizacja renderowania 3D
- **Opis:** Zmniejszyć liczbę trójkątów i poprawić FPS.
- **Kroki:**
  1. Użyć `draco` compression przy eksporcie GLTF.
  2. W `ThreeViewer.jsx` włączyć `useMemo` dla geometrii.
  3. Dodać LOD (Level of Detail) dla modeli daleko od kamery.

## Faza 56 – Dynamiczne materiały i tekstury
- **Opis:** Umożliwić zmianę tekstur w czasie rzeczywistym.
- **Kroki:**
  1. Dodać UI do wyboru tekstury (np. `select` z listą URL).
  2. W `ThreeViewer` użyć `useLoader(TextureLoader, selectedTexture)`.
  3. Zapewnić fallback do domyślnej tekstury.

## Faza 57 – System konfiguracji produktów 3D
- **Opis:** Interaktywny konfigurator z opcjami (kolor, rozmiar, dodatki).
- **Kroki:**
  1. Zdefiniować schemat JSON `productConfigSchema.json`.
  2. Stworzyć komponent `ConfiguratorPanel` synchronizujący stan z `ThreeViewer`.
  3. Zapisać wybraną konfigurację w `localStorage` i umożliwić eksport JSON.

## Faza 58 – Testy wizualne (Chromatic / Storybook)
- **Opis:** Automatyczna weryfikacja UI po zmianach.
- **Kroki:**
  1. Zainstalować `@storybook/react` i skonfigurować Storybook.
  2. Dodać stories dla kluczowych komponentów.
  3. Skonfigurować CI z Chromatic (`npx chromatic --project-token ${{ secrets.CHROMATIC_TOKEN }}`).

## Faza 59 – Accessibility audit (a11y)
- **Opis:** Zapewnienie zgodności z WCAG 2.1 AA.
- **Kroki:**
  1. Zainstalować `axe-core` i `jest-axe`.
  2. Dodać testy `expect(await axe(component)).toHaveNoViolations();`.
  3. Poprawić elementy nieprzyjazne (brak label, kontrast < 4.5:1).

## Faza 60 – Dark mode i tematyzacja
- **Opis:** Wsparcie trybu ciemnego oraz kilku motywów kolorystycznych.
- **Kroki:**
  1. Dodać `prefers-color-scheme` media query w Tailwind.
  2. Stworzyć kontekst `ThemeContext` z przełącznikiem UI.
  3. Zapisać wybór w `localStorage` i przy starcie aplikacji odczytać.

## Faza 61 – Optymalizacja ładowania zasobów (code‑splitting + lazy assets)
- **Opis:** Minimalny rozmiar początkowego bundle.
- **Kroki:**
  1. Przenieść duże obrazy do `public/assets` i ładować je dynamicznie (`import()`).
  2. Użyć `React.lazy` i `Suspense` dla rzadko używanych sekcji UI.
  3. Skonfigurować `vite-plugin-compress` do gzip/brotli.

## Faza 62 – Integracja z AR (augmented reality)
- **Opis:** Wyświetlanie modeli 3D w AR na urządzeniach mobilnych.
- **Kroki:**
  1. Dodać `@react-three/xr` i `three-ar`.
  2. Stworzyć przycisk „View in AR” uruchamiający sesję WebXR.
  3. Przetestować na iOS Safari i Android Chrome.

## Faza 63 – Dokumentacja UI/UX (Storybook + MDX)
- **Opis:** Centralne repozytorium komponentów i ich wariantów.
- **Kroki:**
  1. Dodać `addon-docs` i pisać MDX dla każdego komponentu.
  2. Udostępnić Storybook pod `/storybook` w produkcji.
  3. Zautomatyzować publikację na GitHub Pages po każdym release.

## Faza 64 – Performance profiling (React Profiler & Chrome DevTools)
- **Opis:** Identyfikacja wąskich gardeł renderowania.
- **Kroki:**
  1. Włączyć `React.StrictMode` i `Profiler` w `App.jsx`.
  2. Analizować wyniki w Chrome DevTools → Performance.
  3. Optymalizować przy pomocy `memo`, `useCallback`, `useMemo`.

## Faza 65 – User onboarding flow
- **Opis:** Prowadzenie nowych użytkowników przez kluczowe funkcje.
- **Kroki:**
  1. Zainstalować `react-joyride`.
  2. Zdefiniować kroki onboardingowe (wybór produktu, podgląd 3D, zapis).
  3. Zapisać status ukończenia w `localStorage` i umożliwić ponowne wyświetlenie.

## Faza 66 – Internationalisation rozbudowana (i18n) – wsparcie języków RTL
- **Opis:** Dodanie języków arabskiego i hebrajskiego.
- **Kroki:**
  1. Dodać `dir="rtl"` w `<html>` przy wyborze języka.
  2. Przygotować pliki tłumaczeń `src/locales/ar` i `src/locales/he`.
  3. Przetestować układ UI pod kątem odwróconego kierunku tekstu.

## Faza 67 – System feedbacku i zgłaszania błędów
- **Opis:** Umożliwić użytkownikom zgłaszanie problemów bezpośrednio w UI.
- **Kroki:**
  1. Zintegrować `Sentry` (frontend) i `BugSnag` (backend).
  2. Dodać przycisk „Report issue” otwierający modal z formularzem.
  3. Automatycznie dołączać screenshot i stan aplikacji.

## Faza 68 – Animacje przejść pomiędzy scenami 3D
- **Opis:** Płynne przejścia przy zmianie modelu lub konfiguracji.
- **Kroki:**
  1. W `ThreeViewer` użyć `react-spring` do animacji pozycji/rotacji.
  2. Dodać fade‑out/fade‑in przy zmianie `modelUrl`.
  3. Dostosować czas trwania do 300 ms dla płynności.

## Faza 69 – Optymalizacja pamięci GPU (garbage collection)
- **Opis:** Zapobiegać wyciekom pamięci przy częstych zmianach modeli.
- **Kroki:**
  1. Po każdej zmianie modelu wywołać `dispose()` na geometrii i materiałach.
  2. Użyć `renderer.info.memory` do monitorowania zużycia.
  3. Dodawać testy jednostkowe sprawdzające brak `WebGL` leaks.

## Faza 70 – Podsumowanie UI/UX i roadmapa 3D
- **Opis:** Dokumentacja końcowa, wnioski i plan dalszych iteracji.
- **Kroki:**
  1. Zaktualizować `docs/post-release-review.md` o sekcję *UI/UX & 3D Refactor*.
  2. Stworzyć `docs/roadmap-next-uiux-3d.md` z priorytetami na Q4 2026.
  3. Przeprowadzić prezentację zespołową i zebrać feedback.



