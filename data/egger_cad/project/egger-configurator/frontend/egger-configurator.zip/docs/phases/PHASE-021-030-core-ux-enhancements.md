# Phase 21‑30 – Core UX Enhancements

## Overview
These phases focus on improving the user experience of the Egger + Homag Configurator. They address error handling, loading states, data handling, feature toggles, visual themes, responsiveness, accessibility, and SEO. Each phase is a self‑contained deliverable that can be implemented, tested, and merged independently.

---

### Phase 21 – Error Boundary Component
- **Goal**: Prevent the entire UI from crashing when a component throws an error.
- **Tasks**:
  1. Create `src/components/ErrorBoundary.jsx` using React class component with `componentDidCatch`.
  2. Provide a fallback UI with a friendly message and a “Retry” button.
  3. Wrap top‑level components (`<Wizard />`, `<Configurator />`) with `<ErrorBoundary>`.
  4. Add unit test verifying that an error in a child renders the fallback.
- **Verification**: Manual test – trigger an error (e.g., throw in a dummy component) and confirm fallback appears.

---

### Phase 22 – Loading Skeletons
- **Goal**: Show visual placeholders while data or 3‑D assets load.
- **Tasks**:
  1. Install `react-loading-skeleton` (dev dependency).
  2. Create `src/components/Skeleton.jsx` that accepts `height` and `width` props.
  3. Use skeletons in the product list, material list, and 3‑D preview while awaiting API or model load.
  4. Add a storybook entry (optional) to showcase skeletons.
- **Verification**: Network throttling (slow 3G) – skeletons remain visible until data arrives.

---

### Phase 23 – Pagination / Lazy Load Product List
- **Goal**: Reduce initial payload for large product catalogs.
- **Tasks**:
  1. Extend `public/products.json` to a mock of 200 items (script can generate it).
  2. Implement pagination UI (previous/next buttons) in `WizardStepSelectProduct.jsx`.
  3. Load only the current page (e.g., 20 items) using `search_files` or a simple slice.
  4. Add unit test for pagination logic.
- **Verification**: Verify that the initial bundle size does not include all 200 items.

---

### Phase 24 – React‑Query / SWR Caching Layer
- **Goal**: Cache product and material data, provide stale‑while‑revalidate behavior.
- **Tasks**:
  1. Install `@tanstack/react-query` (or `swr`).
  2. Create `src/api/useProducts.js` and `useMaterials.js` hooks that fetch from `/products.json` and a new `/materials.json`.
  3. Configure query client with a 5‑minute cache time and background refetch on window focus.
  4. Update wizard steps to use these hooks.
- **Verification**: Open the app, navigate away and back – network request should not fire again.

---

### Phase 25 – Feature‑Flag System
- **Goal**: Enable/disable experimental UI parts without redeploy.
- **Tasks**:
  1. Add a simple flag provider (`src/featureFlags.js`) that reads flags from an environment variable `VITE_FEATURE_FLAGS` (comma‑separated list).
  2. Export `useFeatureFlag(name)` hook.
  3. Wrap the new 3‑D model viewer (future GLTF loader) behind a flag `newModelViewer`.
  4. Add a README section describing how to toggle flags.
- **Verification**: Set `VITE_FEATURE_FLAGS=newModelViewer` and confirm the new viewer appears.

---

### Phase 26 – Dark‑Mode Support
- **Goal**: Provide a dark theme that respects user OS preference.
- **Tasks**:
  1. Define CSS variables for colors in `src/styles/theme.css` (light & dark).
  2. Add a `ThemeProvider` context that toggles a `data-theme` attribute on `<html>`.
  3. Include a toggle button in the header.
  4. Persist user choice in `localStorage`.
- **Verification**: Switch themes, reload page – preference persists.

---

### Phase 27 – Responsive Layout & Mobile‑First Design
- **Goal**: Ensure the wizard works on phones, tablets, and desktops.
- **Tasks**:
  1. Refactor layout using CSS Grid / Flexbox with breakpoints (`@media` queries).
  2. Test on common viewport widths (320 px, 768 px, 1024 px).
  3. Adjust touch targets (≥ 44 px) for mobile.
  4. Add a mobile‑only hamburger menu for navigation (if needed).
- **Verification**: Use Chrome DevTools device toolbar – no horizontal scroll, all controls usable.

---

### Phase 28 – Accessibility Audit & ARIA Enhancements
- **Goal**: Meet WCAG 2.1 AA standards.
- **Tasks**:
  1. Run `npm exec axe` (or `@axe-core/react`) on the app.
  2. Add missing `aria-label`, `role`, and `aria‑describedby` attributes to interactive elements.
  3. Ensure focus order follows visual order.
  4. Provide visible focus outlines.
- **Verification**: No violations reported by Axe; screen‑reader test confirms meaningful announcements.

---

### Phase 29 – SEO Meta Tags & Open Graph
- **Goal**: Improve discoverability when the configurator URL is shared.
- **Tasks**:
  1. Install `react-helmet-async`.
  2. Create `src/components/SEO.jsx` that sets `<title>`, `<meta name="description">`, Open Graph tags, and Twitter cards.
  3. Populate tags with dynamic values (product name, material) when a configuration is completed.
  4. Add a fallback static meta set for the landing page.
- **Verification**: Use `curl -I` or view page source – meta tags present.

---

### Phase 30 – Sitemap & robots.txt Generation
- **Goal**: Provide search engines with a crawl map and proper crawling rules.
- **Tasks**:
  1. Add a Vite plugin (`vite-plugin-sitemap`) that generates `dist/sitemap.xml` based on known routes (`/`, `/wizard`, `/preview`).
  2. Create a static `public/robots.txt` allowing all but disallowing `/admin` (future).
  3. Ensure the files are copied to the `dist` folder during build.
  4. Add a CI step that validates the sitemap (e.g., `npm run lint:sitemap`).
- **Verification**: Deploy locally (`npm run preview`) and request `/sitemap.xml` – it returns a well‑formed XML.

---

## Acceptance Criteria for Phases 21‑30
- All new components have unit tests with ≥ 80 % coverage.
- No linting or type errors (`npm run lint` passes).
- CI pipeline runs all new tests and builds successfully.
- Manual QA checklist completed for each phase (error handling, loading states, responsiveness, accessibility, SEO).
- Documentation updated in `README.md` and `docs/` with usage notes for feature flags, dark mode, and SEO.

---

## Next Immediate Action
Create the markdown file above (already done) and commit it to the repository. The subsequent concrete step will be to **implement Phase 21 – Error Boundary Component**.
