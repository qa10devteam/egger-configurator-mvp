import React from 'react';
import { Canvas } from '@react-three/fiber';
import { XR, Controllers } from '@react-three/xr';
import { useLoader } from '@react-three/fiber';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';

function ARViewer({ modelUrl }) {
  const gltf = useLoader(GLTFLoader, modelUrl);
  return (
    <Canvas>
      <XR>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 5, 5]} intensity={0.8} />
        <primitive object={gltf.scene} />
        <Controllers />
      </XR>
    </Canvas>
  );
}

export default ARViewer;
