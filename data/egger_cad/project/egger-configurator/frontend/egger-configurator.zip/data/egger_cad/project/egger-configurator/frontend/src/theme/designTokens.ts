export const designTokens = {
  colors: {
    primary: '#0066ff',
    background: '#ffffff',
    text: '#111111',
    darkBackground: '#111111',
    darkText: '#ffffff',
  },
  fontFamily: `'Inter', sans-serif`,
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
  },
};
